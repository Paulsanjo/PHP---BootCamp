$( document ).ready(function() {


$('#js-button').on('click', function () {
    $.post( window.location.href + 'ajaxCall', 'test', function( data ) {
        alert(data);

    });
});


});