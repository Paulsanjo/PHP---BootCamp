<?php

class News extends Database {


    public function index() {

        include 'News_template.html';
    }


}